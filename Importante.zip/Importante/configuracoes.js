     
     Boas Orientações
       Utilize um sistema baseado no sistema operacional (unix). Como Mec ou Linux.
       Caso você utilize o Windows como sistema operacional, utilise o (wsl).
       WSL -> É uma tecnologia desenvolvida pela Microsoft que permite executar um ambiente 
              Linux dentro do sistema operacional Windows.Caso
    
     